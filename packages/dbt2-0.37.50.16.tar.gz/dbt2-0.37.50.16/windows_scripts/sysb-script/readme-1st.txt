Mind that this configuration was used to test on 512GM RAM/48 physical cores server! This mostly concerns SERVERCL and CLUSTERCL variables.
