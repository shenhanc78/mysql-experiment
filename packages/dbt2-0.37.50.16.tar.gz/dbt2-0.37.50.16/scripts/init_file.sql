rename user root@localhost to root@'%%';
